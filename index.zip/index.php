<?php
// index.php - Landing Page
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: /login3/dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CollabDev — Real-Time Collaboration Platform for Developers</title>
  <meta name="description" content="A collaborative coding platform for development teams. Real-time code editing, team chat, Git integration, and code reviews — all in one place.">
  <link rel="stylesheet" href="/login3/assets/css/app.css">
  <style>
    .landing-page { position: relative; z-index: 1; }
    .section-title { text-align:center; margin-bottom:0.5rem; font-size:clamp(1.5rem,3vw,2.2rem); }
    .section-sub { text-align:center; color:var(--text-secondary); margin-bottom:3rem; font-size:1rem; }
    .tech-stack { display:flex; flex-wrap:wrap; gap:0.75rem; justify-content:center; margin-top:2rem; }
    .tech-pill {
      padding:0.4rem 1rem; background:var(--bg-secondary);
      border:1px solid var(--border-muted); border-radius:var(--radius-full);
      font-size:0.82rem; color:var(--text-secondary);
      display:flex; align-items:center; gap:0.4rem;
    }
    .footer { border-top:1px solid var(--border-muted); padding:2rem; text-align:center; color:var(--text-muted); font-size:0.85rem; }
    .glow-text { animation: glow-pulse 3s ease-in-out infinite; }
    @keyframes glow-pulse {
      0%,100% { text-shadow: 0 0 20px rgba(88,166,255,.3); }
      50% { text-shadow: 0 0 40px rgba(88,166,255,.6); }
    }
  </style>
</head>
<body class="landing-bg">

<!-- Navigation -->
<nav class="landing-nav" id="main-nav">
  <a href="/login3/" class="logo">
    <div class="logo-icon">⚡</div>
    CollabDev
  </a>
  <div class="flex items-center gap-3">
    <a href="/login3/login.php" class="btn btn-ghost">Sign in</a>
    <a href="/login3/register.php" class="btn btn-blue">Get Started Free</a>
  </div>
</nav>

<!-- Hero -->
<section class="hero landing-page">
  <div class="hero-badge" style="animation:slideUp 0.5s ease">
    <span>⚡</span> Real-Time • Collaborative • Powerful
  </div>
  <h1 class="glow-text">Code Together.<br>Ship Faster.</h1>
  <p>
    A collaborative coding platform that brings your team together with live editing,
    instant chat, Git version control, and code reviews — all in one elegant workspace.
  </p>
  <div class="hero-actions">
    <a href="/login3/register.php" class="btn btn-blue btn-lg" id="hero-cta">
      🚀 Start Coding Free
    </a>
    <a href="/login3/login.php" class="btn btn-secondary btn-lg" id="hero-login">
      Sign in → Demo
    </a>
  </div>
</section>

<!-- Terminal Preview -->
<div style="padding:0 2rem;position:relative;z-index:1;max-width:820px;margin:0 auto">
  <div class="terminal-preview">
    <div class="terminal-bar">
      <div class="terminal-dot red"></div>
      <div class="terminal-dot yellow"></div>
      <div class="terminal-dot green"></div>
      <span class="terminal-title">project/src/api.php — CollabDev</span>
    </div>
    <div class="terminal-body">
      <div><span class="c-purple">class</span> <span class="c-blue">UserController</span> {</div>
      <div>&nbsp;&nbsp;<span class="c-green">// 🟢 alice is editing here</span></div>
      <div>&nbsp;&nbsp;<span class="c-purple">public function</span> <span class="c-blue">getUser</span>(<span class="c-yellow">$id</span>) {</div>
      <div>&nbsp;&nbsp;&nbsp;&nbsp;<span class="c-yellow">$user</span> = <span class="c-blue">User</span>::<span class="c-blue">findOrFail</span>(<span class="c-yellow">$id</span>);</div>
      <div>&nbsp;&nbsp;&nbsp;&nbsp;<span class="c-purple">return</span> <span class="c-blue">response</span>()-><span class="c-blue">json</span>(<span class="c-yellow">$user</span>);</div>
      <div>&nbsp;&nbsp;}</div>
      <div>}</div>
      <div>&nbsp;</div>
      <div><span class="c-gray">// 💬 Chat | alice: "should we add auth middleware?" | bob: "yes, good idea 👍"</span></div>
      <div><span class="c-gray">// ✔ git commit -m "feat: add user controller"  [main 3f2a1bc]</span></div>
      <div><span class="c-green">$</span> <span class="cursor-blink"></span></div>
    </div>
  </div>
</div>

<!-- Features -->
<section style="padding:2rem 0 1rem">
  <h2 class="section-title" style="margin-top:3rem">Everything Your Team Needs</h2>
  <p class="section-sub">A complete developer collaboration suite, built for speed</p>
  <div class="features-grid">
    <div class="feature-card">
      <div class="feature-icon" style="background:rgba(88,166,255,.1)">✏️</div>
      <h3>Real-Time Code Editor</h3>
      <p>Multiple developers editing the same file simultaneously with live sync, syntax highlighting for 10+ languages, and cursor tracking.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon" style="background:rgba(63,185,80,.1)">💬</div>
      <h3>Team Chat</h3>
      <p>Built-in instant messaging right beside your editor. Discuss code, share snippets with inline formatting, no switching apps.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon" style="background:rgba(188,140,255,.1)">🌿</div>
      <h3>Git Version Control</h3>
      <p>Commit, branch, and track changes. Full visual diff viewer to compare any two versions of your code with highlighted changes.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon" style="background:rgba(210,153,34,.1)">🔍</div>
      <h3>Code Reviews</h3>
      <p>Request reviews, add inline comments on specific lines, and manage approvals with a clean pull-request style workflow.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon" style="background:rgba(255,166,87,.1)">📁</div>
      <h3>Project Management</h3>
      <p>Organize files and folders per project. Invite teammates by email with role-based access: Owner, Collaborator, or Viewer.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon" style="background:rgba(248,81,73,.1)">🔐</div>
      <h3>Secure Authentication</h3>
      <p>Session-based auth with bcrypt-hashed passwords, role-based permissions, and project privacy controls.</p>
    </div>
  </div>
</section>

<!-- Tech Stack -->
<section style="padding:3rem 2rem;text-align:center;position:relative;z-index:1">
  <h2 class="section-title">Built With</h2>
  <p class="section-sub">Modern, proven technologies</p>
  <div class="tech-stack">
    <div class="tech-pill">🐘 PHP 8</div>
    <div class="tech-pill">📜 JavaScript</div>
    <div class="tech-pill">🗄️ MySQL</div>
    <div class="tech-pill">📡 AJAX Polling</div>
    <div class="tech-pill">✏️ CodeMirror</div>
    <div class="tech-pill">🎨 Bootstrap 5</div>
    <div class="tech-pill">🌿 Git</div>
    <div class="tech-pill">🔐 Bcrypt</div>
  </div>
</section>

<!-- CTA Banner -->
<section style="padding:4rem 2rem;text-align:center;position:relative;z-index:1">
  <div style="max-width:600px;margin:0 auto;background:var(--bg-secondary);border:1px solid var(--border-default);border-radius:var(--radius-xl);padding:3rem 2rem;box-shadow:var(--shadow-md)">
    <div style="font-size:2.5rem;margin-bottom:1rem">🚀</div>
    <h2 style="margin-bottom:0.75rem">Ready to collaborate?</h2>
    <p style="color:var(--text-secondary);margin-bottom:2rem">Create your free account and start building with your team today.</p>
    <a href="/login3/register.php" class="btn btn-blue btn-lg" id="footer-cta">Create Free Account</a>
    <div style="margin-top:1rem;font-size:0.82rem;color:var(--text-muted)">
      Demo: <strong style="color:var(--text-secondary)">demo@example.com</strong> / <strong style="color:var(--text-secondary)">demo123</strong>
    </div>
  </div>
</section>

<footer class="footer">
  <p>CollabDev &copy; <?= date('Y') ?> — Real-Time Collaboration Platform for Developers</p>
  <p style="margin-top:0.4rem">Built with PHP · JavaScript · MySQL · CodeMirror</p>
</footer>

<div class="toast-container" id="toast-container"></div>
<script src="/login3/assets/js/app.js"></script>
<script>
  // Animate feature cards on scroll
  const observer = new IntersectionObserver(entries => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        entry.target.style.animationDelay = `${i * 0.05}s`;
        entry.target.classList.add('animate-slide-up');
      }
    });
  }, { threshold: 0.1 });
  document.querySelectorAll('.feature-card').forEach(el => observer.observe(el));
</script>
</body>
</html>
